----------------------BY YZZOW AND DHZ----------------------
-------------------discord.gg/ZKJcrDddYx--------------------
----------------------BY YZZOW AND DHZ----------------------
local ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(1000)
	end
end)

local BaseMenu = ContextUI:CreateMenu(1, "Personne") 
local Tblanchiment = ContextUI:CreateSubMenu(BaseMenu, "Taux")
local Blanchimentwola = ContextUI:CreateSubMenu(BaseMenu, "Blanchire")

ContextUI:IsVisible(BaseMenu, function(Entity)
    if Entity.Model == -795819184 then 
        ContextUI:Button("~b~Taux de blanchiment", nil, function(Selected)
            if (Selected) then
                TexteBas('~r~[Inconnu]~s~ Yo tu veux connaitre les taux de blanchiment man?', 2500)
                Citizen.Wait(2500)
            end
        end, Tblanchiment)
        ContextUI:Button("~b~Blanchir", nil, function(Selected)
            if (Selected) then
            end
        end, Blanchimentwola)
    end
end)

ContextUI:IsVisible(Tblanchiment, function(Entity)
    ContextUI:Button("~g~Oui", nil, function(Selected)
        if (Selected) then
            TexteBas('~b~[Vous]~s~ Oui', 2500)
            Citizen.Wait(2500)
            TexteBas('~r~[Inconnu]~s~ Mes taux de blanchiment sont de 25%', 2500)
        end
    end,Blanchimentwola)
    ContextUI:Button("~r~Non", nil, function(Selected)
        if (Selected) then
            TexteBas('~b~[Vous]~s~ Non', 2500)
            Citizen.Wait(2500)
            TexteBas('~r~[Inconnu]~s~ Bah degage alors ', 2500)      
        end
    end,BaseMenu)
end)

ContextUI:IsVisible(Blanchimentwola, function(Entity)
    ContextUI:Button("~g~Blanchire~r~ l\'argent sale", nil, function(Selected)
        if (Selected) then
            local argent = KeyboardInput('Combien veux tu blanchir ?', '', '', 8)
            TriggerServerEvent('Yblanchi:blanchiement', argent)
        end
    end)
end)

Keys.Register("LMENU", "LMENU", "BaseMenu", function()
    ContextUI.Focus = not ContextUI.Focus;
end)

Citizen.CreateThread(function()
    for _, item in pairs(Config.npc) do
        RequestModel(item.hash)
        while not HasModelLoaded(item.hash) do
            Wait(1)
        end
        ped =  CreatePed(5, item.hash, item.x, item.y, item.z-0.92, item.a, false, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
    end
end)

function TexteBas(msg, time)
    ClearPrints()
    BeginTextCommandPrint('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandPrint(time, 1)
end

function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", 10)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end