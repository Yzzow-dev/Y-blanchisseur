Config = {}

Config.Pourcent = 0.80 -- il prend 20% (1- 0,80 = 0,20)
Config.time = 180000 --en millisecondes


Config.npc = {
    {hash= -795819184, x=23.35, y=-424.97, z=55.2, a=55.2}, -- vous pouvez en mettre plusieur a des endroit different mais il auront quand meme le meme %
}
