----------------------BY YZZOW AND DHZ----------------------
-------------------discord.gg/ZKJcrDddYx--------------------
----------------------BY YZZOW AND DHZ----------------------
ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('Yblanchi:blanchiement')
AddEventHandler('Yblanchi:blanchiement', function(argent)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local taxe = Config.Pourcent

    argent = ESX.Math.Round(tonumber(argent))
    pourcentage = argent * taxe
    Total = ESX.Math.Round(tonumber(pourcentage))

    if argent > 0 and xPlayer.getAccount('black_money').money >= argent then
        xPlayer.removeAccountMoney('black_money', argent)
        TriggerClientEvent('esx:showAdvancedNotification', xPlayer.source, 'Information', 'Blanchiment', 'Attends ~r~' .. Config.time / 1000 .. ' secondes', 'CHAR_MP_DETONATEPHONE', 8)
        Citizen.Wait(Config.time)
        
        TriggerClientEvent('esx:showAdvancedNotification', xPlayer.source, 'Information', 'Blanchiment', 'Tu as reçu : ' .. ESX.Math.GroupDigits(Total) .. ' ~g~$', 'CHAR_MP_DETONATEPHONE', 8)    
        xPlayer.addMoney(Total)
        else
        TriggerClientEvent('esx:showAdvancedNotification', xPlayer.source, 'Information', 'Blanchiment', '~r~Montant invalide', 'CHAR_MP_DETONATEPHONE', 8)
    end    
end)